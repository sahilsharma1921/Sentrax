import React from 'react';

export const Badge = ({ children, variant = 'default', className = '' }) => {
  const styles = {
    default: 'bg-white/10 text-gray-300 border-white/10',
    primary: 'bg-primary/15 text-primary border-primary/30',
    danger: 'bg-danger/15 text-danger border-danger/30',
    warning: 'bg-warning/15 text-warning border-warning/30',
    success: 'bg-success/15 text-success border-success/30',
    info: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border font-mono tracking-tight ${styles[variant]} ${className}`}>
      {children}
    </span>
  );
};